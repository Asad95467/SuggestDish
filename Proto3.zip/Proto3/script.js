const ingredientsByCategory = {
    Meat: ["Mutton", "Beef", "Chicken", "Lamb meat", "Fish", "Lobster", "Crab"],
    Vegetables: ["Potato", "Okra (Ladyfinger)", "Eggplant (Brinjal)", "Spinach", "Bottle Gourd", "Bitter Gourd", "Apple Gourd", "Cauliflower", "Fenugreek Leaves", "Tomato", "Bell Pepper", "Peas", "Carrot", "Onion", "Lettuce", "Lemon", "Parsley"],
    Lentils: ["Lentils", "Chickpeas", "Black Lentils", "Kidney Beans"],
    Flour: ["Gram Flour", "Whole-wheat Flour", "Flour", "Wheat", "Semolina"],
    Rice: ["Basmati", "Sella", "Rice"],
    "Dairy Products": ["Paneer", "Yogurt", "Khoya", "Butter", "Milk", "Cheese"],
    Spices: ["Ginger", "Garlic", "Green Chili", "Cardamom", "Spices", "Tikka Masala", "Nihari Masala", "Chana Masala", "Pickle Spices"],
    "Other Items": ["Sugar", "Oil", "Olive Oil", "Pasta", "Nuts", "Vegetables (generic)"]
};

const dishes = [
{ "name": "Daal Chawal", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Lentils", "Basmati", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Aloo Palak", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Potato", "Spinach", "Ginger", "Garlic", "Spices"] },
  { "name": "Bhindi Masala", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Okra (Ladyfinger)", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Baingan Bharta", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Eggplant (Brinjal)", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Chana Masala", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chickpeas", "Tomato", "Onion", "Garlic", "Ginger", "Chana Masala"] },
  { "name": "Aloo Gobi", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Potato", "Cauliflower", "Ginger", "Garlic", "Spices"] },
  { "name": "Daal Tadka", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Lentils", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Palak Paneer", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Spinach", "Paneer", "Ginger", "Garlic", "Spices"] },
  { "name": "Aloo Matar", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Potato", "Peas", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Mix Veg Sabzi", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Potato", "Carrot", "Peas", "Cauliflower", "Ginger", "Garlic", "Spices"] },
  { "name": "Lauki Chana", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Bottle Gourd", "Chickpeas", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Karela Sabzi", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Bitter Gourd", "Onion", "Tomato", "Ginger", "Garlic", "Spices"] },
  { "name": "Tinda Masala", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Apple Gourd", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Aloo Methi", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Potato", "Fenugreek Leaves", "Ginger", "Garlic", "Spices"] },
  { "name": "Bhindi Fry", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Okra (Ladyfinger)", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Daal Makhani", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Black Lentils", "Kidney Beans", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Moong Daal Bariyaan", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Lentil", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Besan Gatte ki Sabzi", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Gram Flour", "Tomato", "Onion", "Ginger", "Garlic", "Oil", "Yogurt", "Spices"] },
  { "name": "Paneer Bhurji", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Paneer", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Aloo Bhujia", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Potato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Aloo Paratha", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Potato", "Whole-wheat Flour", "Ginger", "Green Chili", "Spices"] },
  { "name": "Gobhi Masala", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Cauliflower", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Methi Paratha", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Fenugreek Leaves", "Whole-wheat Flour", "Ginger", "Green Chili", "Spices"] },
  { "name": "Biryani", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Basmati", "Chicken", "Yogurt", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Karahi Gosht", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Mutton", "Tomato", "Ginger", "Garlic", "Green Chili", "Spices"] },
  { "name": "Haleem", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Wheat", "Lentils", "Mutton", "Ginger", "Garlic", "Spices"] },
  { "name": "Nihari", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Ginger", "Garlic", "Nihari Masala", "Flour"] },
  { "name": "Chicken Tikka", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Yogurt", "Tikka Masala", "Ginger", "Garlic"] },
  { "name": "Seekh Kebab", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Ginger", "Garlic", "Spices"] },
  { "name": "Murgh Chana", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Chickpeas", "Spices", "Tomato"] },
  { "name": "Chicken Karahi", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Tomato", "Ginger", "Garlic", "Green Chili", "Spices"] },
  { "name": "Aloo Gosht", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Potato", "Tomato", "Ginger", "Garlic", "Spices"] },
  { "name": "Chicken Korma", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Yogurt", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Beef Kofta", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Chicken Biryani", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Basmati", "Chicken", "Yogurt", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Mutton Pulao", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Basmati", "Mutton", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Beef Nihari", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Ginger", "Garlic", "Nihari Masala", "Flour"] },
  { "name": "Chicken Pulao", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Basmati", "Chicken", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Chicken Haleem", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Wheat", "Lentils", "Ginger", "Garlic", "Spices"] },
  { "name": "Beef Karahi", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Tomato", "Ginger", "Garlic", "Green Chili", "Spices"] },
  { "name": "Chicken Handi", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Yogurt", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Mutton Korma", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Mutton", "Yogurt", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Chicken Jalfrezi", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Bell Pepper", "Onion", "Tomato", "Ginger", "Garlic", "Spices"] },
  { "name": "Hyderabadi Beef Pulao", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Sella", "Beef", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Chicken Roast", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Ginger", "Garlic", "Spices"] },
  { "name": "Mutton Biryani", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Basmati", "Mutton", "Yogurt", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Chicken Curry", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Beef Curry", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Mutton Curry", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Mutton", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Chicken Masala", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Beef Masala", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Mutton Masala", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Mutton", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Chicken Qorma", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Yogurt", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Beef Qorma", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Yogurt", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Mutton Qorma", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Mutton", "Yogurt", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Chicken Achari", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Pickle Spices", "Onion", "Garlic", "Ginger"] },
  { "name": "Beef Achari", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Pickle Spices", "Onion", "Garlic", "Ginger"] },
  { "name": "Mutton Achari", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Mutton", "Pickle Spices", "Onion", "Garlic", "Ginger"] },
  { "name": "Chicken Bhuna", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Beef Bhuna", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Mutton Bhuna", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Mutton", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Chicken Shami Kebab", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Lentils", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Beef Shami Kebab", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Lentils", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Mutton Shami Kebab", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Mutton", "Lentils", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Chicken Reshmi Kebab", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Yogurt", "Ginger", "Garlic", "Spices"] },
  { "name": "Beef Reshmi Kebab", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Yogurt", "Ginger", "Garlic", "Spices"] },
  { "name": "Mutton Reshmi Kebab", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Mutton", "Yogurt", "Ginger", "Garlic", "Spices"] },
  { "name": "Chicken Malai Boti", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Yogurt", "Ginger", "Garlic", "Spices"] },
  { "name": "Beef Malai Boti", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Yogurt", "Ginger", "Garlic", "Spices"] },
  { "name": "Mutton Malai Boti", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Mutton", "Yogurt", "Ginger", "Garlic", "Spices"] },
  { "name": "Fish Masala", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Fish", "Onions", "Tomato", "Spices", "Oil", "Ginger", "Garlic"] },
  { "name": "Fish Grilled", "cuisine": "Pakistani", "calories": "350Kcal per 300g serving", "ingredients": ["Fish", "Spices", "Oil", "Ginger", "Garlic", "Lemon"] },
  { "name": "Butter Chicken", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Tomato", "Butter", "Yogurt", "Ginger", "Garlic", "Spices"] },
  { "name": "Palak Paneer", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Spinach", "Paneer", "Ginger", "Garlic", "Spices"] },
  { "name": "Chole Bhature", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Chickpeas", "Flour", "Yogurt", "Ginger", "Garlic", "Spices"] },
  { "name": "Rajma", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Kidney Beans", "Tomato", "Onion", "Garlic", "Ginger", "Spices"] },
  { "name": "Paneer Tikka", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Paneer", "Yogurt", "Ginger", "Garlic", "Spices"] },
  { "name": "Aloo Gobi", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Potato", "Cauliflower", "Ginger", "Garlic", "Spices"] },
  { "name": "Samosa", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Potato", "Flour", "Peas", "Ginger", "Garlic", "Spices"] },
  { "name": "Paneer Butter Masala", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Paneer", "Tomato", "Butter", "Yogurt", "Ginger", "Garlic", "Spices"] },
  { "name": "Dhokla", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Gram Flour", "Yogurt", "Ginger", "Green Chili", "Spices"] },
  { "name": "Idli", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Rice", "Lentils", "Ginger", "Green Chili", "Spices"] },
  { "name": "Dosa", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Rice", "Lentils", "Ginger", "Green Chili", "Spices"] },
  { "name": "Vada", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Lentils", "Ginger", "Green Chili", "Spices"] },
  { "name": "Upma", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Semolina", "Onion", "Ginger", "Green Chili", "Spices"] },
  { "name": "Pongal", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Rice", "Lentils", "Ginger", "Green Chili", "Spices"] },
  { "name": "Rasam", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Tomato", "Lentils", "Ginger", "Garlic", "Spices"] },
  { "name": "Sambar", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Lentils", "Vegetables", "Ginger", "Garlic", "Spices"] },
  { "name": "Paneer Bhurji", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Paneer", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Aloo Matar", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Potato", "Peas", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Baingan Bharta", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Eggplant", "Tomato", "Onion", "Ginger", "Garlic", "Spices"] },
  { "name": "Pav Bhaji", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Vegetables", "Butter", "Ginger", "Garlic", "Spices"] },
  { "name": "Kheer", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Rice", "Milk", "Sugar", "Cardamom"] },
  { "name": "Gulab Jamun", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Khoya", "Flour", "Sugar", "Cardamom"] },
  { "name": "Rasgulla", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Paneer", "Sugar", "Cardamom"] },
  { "name": "Jalebi", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Flour", "Sugar", "Cardamom"] },
  { "name": "Lassi", "cuisine": "Indian", "calories": "350Kcal per 300g serving", "ingredients": ["Yogurt", "Milk", "Sugar", "Cardamom"] },
  { "name": "Shawarma", "cuisine": "Arabic", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Yogurt", "Garlic", "Spices"] },
  { "name": "Falafel", "cuisine": "Arabic", "calories": "350Kcal per 300g serving", "ingredients": ["Chickpeas", "Garlic", "Spices"] },
  { "name": "Hummus", "cuisine": "Arabic", "calories": "350Kcal per 300g serving", "ingredients": ["Chickpeas", "Garlic", "Olive Oil", "Spices"] },
  { "name": "Tabbouleh", "cuisine": "Arabic", "calories": "350Kcal per 300g serving", "ingredients": ["Parsley", "Tomato", "Onion", "Olive Oil", "Spices"] },
  { "name": "Kebabs", "cuisine": "Arabic", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Onion", "Garlic", "Spices"] },
  { "name": "Mansaf", "cuisine": "Arabic", "calories": "350Kcal per 300g serving", "ingredients": ["Lamb meat", "Yogurt", "Rice", "Spices"] },
  { "name": "Fattoush", "cuisine": "Arabic", "calories": "350Kcal per 300g serving", "ingredients": ["Lettuce", "Tomato", "Onion", "Olive Oil", "Spices"] },
  { "name": "Kofta", "cuisine": "Arabic", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Onion", "Garlic", "Spices"] },
  { "name": "Maqluba", "cuisine": "Arabic", "calories": "350Kcal per 300g serving", "ingredients": ["Rice", "Chicken", "Eggplant", "Spices"] },
  { "name": "Baklava", "cuisine": "Arabic", "calories": "350Kcal per 300g serving", "ingredients": ["Flour", "Butter", "Sugar", "Nuts"] },
  { "name": "Spaghetti Bolognese", "cuisine": "Continental", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Tomato", "Onion", "Garlic", "Olive Oil", "Spices"] },
  { "name": "Grilled Chicken", "cuisine": "Continental", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Olive Oil", "Garlic", "Spices"] },
  { "name": "Caesar Salad", "cuisine": "Continental", "calories": "350Kcal per 300g serving", "ingredients": ["Lettuce", "Chicken", "Olive Oil", "Garlic", "Spices"] },
  { "name": "Beef Steak", "cuisine": "Continental", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Olive Oil", "Garlic", "Spices"] },
  { "name": "Chicken Alfredo", "cuisine": "Continental", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Pasta", "Butter", "Garlic", "Spices"] },
  { "name": "Fish and Chips", "cuisine": "Continental", "calories": "350Kcal per 300g serving", "ingredients": ["Fish", "Potato", "Flour", "Spices"] },
  { "name": "Lasagna", "cuisine": "Continental", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Tomato", "Onion", "Garlic", "Olive Oil", "Spices"] },
  { "name": "Pizza Margherita", "cuisine": "Continental", "calories": "350Kcal per 300g serving", "ingredients": ["Tomato", "Cheese", "Olive Oil", "Garlic", "Spices"] },
  { "name": "Chicken Parmesan", "cuisine": "Continental", "calories": "350Kcal per 300g serving", "ingredients": ["Chicken", "Tomato", "Cheese", "Olive Oil", "Garlic", "Spices"] },
  { "name": "Beef Burger", "cuisine": "Continental", "calories": "350Kcal per 300g serving", "ingredients": ["Beef", "Onion", "Garlic", "Spices"] } 
];

const categoryColors = {
    Meat: "#ff8282",
    Vegetables: "#81c784",
    Lentils: "#FFD700",
    Flour: "#ffae4c",
    Rice: "#7da7ca",
    "Dairy Products": "#b967c7",
    Spices: "#f5554a",
    "Other Items": "#9e9e9e"
};

const selectedIngredients = new Set();

const ingredientsContainer = document.getElementById("ingredients-container");
const dishContainer = document.getElementById("dish-container");
const suggestBtn = document.getElementById("suggest-btn");

// Generate ingredient buttons
Object.entries(ingredientsByCategory).forEach(([category, ingredients]) => {
    const categoryDiv = document.createElement("div");
    categoryDiv.classList.add("ingredients-category");

    const categoryTitle = document.createElement("h2");
    categoryTitle.innerText = category;
    categoryDiv.appendChild(categoryTitle);

    ingredients.forEach(ingredient => {
        const button = document.createElement("button");
        button.innerText = ingredient;
        button.classList.add("ingredient-btn");
        button.style.backgroundColor = categoryColors[category];

        button.addEventListener("click", () => {
            if (selectedIngredients.has(ingredient)) {
                selectedIngredients.delete(ingredient);
                button.classList.remove("selected");
            } else {
                selectedIngredients.add(ingredient);
                button.classList.add("selected");
            }
        });

        categoryDiv.appendChild(button);
    });

    ingredientsContainer.appendChild(categoryDiv);
});

// Suggest dishes
suggestBtn.addEventListener("click", () => {
    dishContainer.innerHTML = "";

    const selectedArray = Array.from(selectedIngredients);
    const suggestedDishes = dishes.filter(dish =>
        dish.ingredients.every(ingredient => selectedArray.includes(ingredient))
    );

    if (suggestedDishes.length === 0) {
        dishContainer.innerHTML = "<p>No matching dishes. Select more ingredients.</p>";
    } else {
        suggestedDishes.forEach(dish => {
            const dishCard = document.createElement("div");
            dishCard.classList.add("dish-card");

            dishCard.innerHTML = `
                <h3>${dish.name}</h3>
                <p><strong>Cuisine:</strong> ${dish.cuisine}</p>
                <p><strong>Calories:</strong> ${dish.calories}</p>
                <p><strong>Ingredients:</strong> ${dish.ingredients.join(", ")}</p>
            `;

            dishContainer.appendChild(dishCard);
        });
    }
});
